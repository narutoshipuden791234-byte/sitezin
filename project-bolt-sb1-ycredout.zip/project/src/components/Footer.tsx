export default function Footer() {
  return (
    <footer className="relative z-10 bg-green-950/90 text-white py-8 mt-16 border-t-4 border-yellow-400">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center gap-6 mb-6">
          <a
            href="#home"
            className="hover:text-yellow-400 transition-colors font-medium"
          >
            Início
          </a>
          <span className="text-yellow-400">|</span>
          <a
            href="#suporte"
            className="hover:text-yellow-400 transition-colors font-medium"
          >
            Suporte
          </a>
          <span className="text-yellow-400">|</span>
          <a
            href="#ganhadores"
            className="hover:text-yellow-400 transition-colors font-medium"
          >
            Ganhadores
          </a>
          <span className="text-yellow-400">|</span>
          <a
            href="#privacidade"
            className="hover:text-yellow-400 transition-colors font-medium"
          >
            Política de Privacidade
          </a>
        </div>

        <div className="text-center text-sm text-gray-300">
          <p className="mb-2">Promoção de Natal 2025 - TikTok Lite</p>
          <p>Aproveite enquanto durarem as vagas!</p>
        </div>
      </div>
    </footer>
  );
}
