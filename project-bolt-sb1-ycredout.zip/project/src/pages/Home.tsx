import { Gift, Star, Heart, Sparkles, CheckCircle } from 'lucide-react';

const TIKTOK_LINK = 'https://www.tiktok.com/d/4/ZSHKumCqQg4M4-t7RLE/';

export default function Home() {
  const testimonials = [
    {
      name: 'Ana',
      city: 'SP',
      text: 'Adorei! Caiu rapidinho no Pix, perfeito pro Natal da família',
    },
    {
      name: 'João',
      city: 'RJ',
      text: 'Melhor surpresa do ano! Sem gastar nada.',
    },
    {
      name: 'Maria',
      city: 'MG',
      text: 'Recomendo, é real e super fácil.',
    },
    {
      name: 'Pedro',
      city: 'DF',
      text: 'Surpresa incrível! Já usei pro presente das crianças',
    },
    {
      name: 'Juliana',
      city: 'BA',
      text: 'Fácil e rápido, caiu no mesmo dia. Obrigada!',
    },
  ];

  return (
    <div className="pt-12 pb-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <section className="text-center mb-12 bg-white/10 backdrop-blur-md rounded-3xl p-8 md:p-12 shadow-2xl border-4 border-yellow-400/30">
          <div className="mb-6">
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
              Uma Surpresa Especial de Natal 🎄
            </h2>
            <p className="text-xl md:text-2xl text-yellow-200 font-medium">
              Nessa época mágica, todo mundo merece um presentinho extra... direto no Pix
            </p>
          </div>

          <div className="bg-white/95 rounded-2xl p-6 md:p-8 text-left my-8 shadow-xl">
            <p className="text-gray-800 text-lg md:text-xl leading-relaxed mb-4">
              <span className="font-bold text-2xl">Oi! 😊</span>
            </p>

            <p className="text-gray-700 text-base md:text-lg leading-relaxed mb-4">
              Eu quase deixei passar, mas foi a melhor surpresa desse Natal.
            </p>

            <p className="text-gray-700 text-base md:text-lg leading-relaxed mb-4">
              Baixei um app simples pelo link especial, criei a conta rapidinho e segui umas etapas fáceis...
            </p>

            <p className="text-gray-700 text-base md:text-lg leading-relaxed mb-4">
              E ganhei uma ajudinha boa que caiu direto no meu Pix, <span className="font-bold text-green-700">sem precisar investir nada, sem sorteio e sem complicação.</span>
            </p>

            <p className="text-gray-700 text-base md:text-lg leading-relaxed mb-4">
              É uma promoção limitada de Natal do <span className="font-bold text-red-600">TikTok Lite</span> que está pagando mesmo pra quem entra agora.
            </p>

            <p className="text-gray-700 text-base md:text-lg leading-relaxed mb-4">
              Muita gente já resgatou e está usando pro presente dos filhos, ceia ou até uma viagem no fim de ano.
            </p>

            <p className="text-gray-800 text-xl md:text-2xl font-bold text-center mt-6">
              Quer a sua surpresa também?
            </p>
          </div>

          <a
            href={TIKTOK_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block w-full md:w-auto"
          >
            <button className="w-full md:w-auto bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold text-xl md:text-2xl py-5 px-10 rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300 border-4 border-yellow-400 flex items-center justify-center gap-3 mx-auto">
              <Gift className="w-8 h-8" />
              Clique aqui e resgate seu presentinho de Natal 🎁
            </button>
          </a>

          <p className="text-yellow-200 text-sm md:text-base mt-4 font-medium">
            Bônus de até R$170 no Pix • Sem investimento • Sem sorteio
          </p>
        </section>

        <section className="mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-center text-white mb-4 drop-shadow-lg">
            Como funciona? É bem simples 🎄
          </h3>
          <p className="text-center text-yellow-200 text-lg mb-8">
            Seguindo estes 3 passos simples, você recebe seu bônus
          </p>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <div className="bg-white/95 rounded-2xl p-8 shadow-xl text-center border-4 border-red-400/50 transform hover:scale-105 transition-all duration-300">
              <div className="bg-red-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-3xl font-bold shadow-lg">
                1
              </div>
              <h4 className="text-xl font-bold text-gray-800 mb-2">Clique no link</h4>
              <p className="text-gray-700">Entre pelo link especial da promoção</p>
            </div>

            <div className="bg-white/95 rounded-2xl p-8 shadow-xl text-center border-4 border-yellow-400/50 transform hover:scale-105 transition-all duration-300">
              <div className="bg-yellow-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-3xl font-bold shadow-lg">
                2
              </div>
              <h4 className="text-xl font-bold text-gray-800 mb-2">Baixe e cadastre</h4>
              <p className="text-gray-700">Instale o TikTok Lite e faça seu cadastro</p>
            </div>

            <div className="bg-white/95 rounded-2xl p-8 shadow-xl text-center border-4 border-green-400/50 transform hover:scale-105 transition-all duration-300">
              <div className="bg-green-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 text-3xl font-bold shadow-lg">
                3
              </div>
              <h4 className="text-xl font-bold text-gray-800 mb-2">Receba no Pix</h4>
              <p className="text-gray-700">Complete as etapas e ganhe seu bônus</p>
            </div>
          </div>
        </section>

        <section className="mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-center text-white mb-8 drop-shadow-lg">
            Veja o que estão dizendo 💬
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white/95 rounded-2xl p-6 shadow-xl transform hover:scale-105 transition-all duration-300 border-2 border-yellow-400/50"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div>
                    <p className="font-bold text-gray-800 text-lg">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.city}</p>
                  </div>
                </div>
                <p className="text-gray-700 text-base leading-relaxed mb-3">
                  "{testimonial.text}"
                </p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="text-center bg-gradient-to-r from-yellow-400 to-yellow-500 rounded-3xl p-8 shadow-2xl">
          <h3 className="text-2xl md:text-3xl font-bold text-red-900 mb-4">
            Não perca essa oportunidade! 🎅
          </h3>
          <p className="text-red-900 text-lg mb-6">
            Milhares de pessoas já garantiram a surpresa de Natal. Seja o próximo!
          </p>
          <a
            href={TIKTOK_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block w-full md:w-auto"
          >
            <button className="w-full md:w-auto bg-red-700 hover:bg-red-800 text-white font-bold text-xl py-4 px-8 rounded-full shadow-xl transform hover:scale-105 transition-all duration-300 border-4 border-white">
              Quero minha surpresa agora! 🎁
            </button>
          </a>
        </section>
      </div>
    </div>
  );
}
