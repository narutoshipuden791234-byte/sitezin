import { useState } from 'react';
import { ChevronDown, ChevronUp, MessageCircle, Gift } from 'lucide-react';

const TIKTOK_LINK = 'https://www.tiktok.com/d/4/ZSHKumCqQg4M4-t7RLE/';
const WHATSAPP_NUMBER = '5551981749870';

export default function Suporte() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const faqs = [
    {
      question: 'É de verdade?',
      answer: 'Sim! É uma promoção oficial do TikTok Lite. Muita gente já recebeu direto no Pix.',
    },
    {
      question: 'Preciso investir dinheiro?',
      answer: 'Não! Zero investimento, zero depósito. Só baixar e seguir as etapas.',
    },
    {
      question: 'É sorteio?',
      answer: 'Não, é bônus garantido pra quem entra pelo link e completa o cadastro.',
    },
    {
      question: 'Quanto tempo demora?',
      answer: 'Geralmente cai rápido no Pix após as etapas simples.',
    },
    {
      question: 'Não recebi, e agora?',
      answer: `Me chama aqui no WhatsApp que eu te ajudo passo a passo: ${WHATSAPP_NUMBER}`,
    },
  ];

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <div className="pt-12 pb-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <section className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Dúvidas? Estamos aqui pra ajudar 🎅
          </h1>
          <p className="text-xl text-yellow-200">
            Qualquer coisa é só chamar! Aqui vão as dúvidas mais comuns sobre a surpresa de Natal:
          </p>
        </section>

        <section className="mb-12 bg-white/95 rounded-3xl p-6 md:p-8 shadow-2xl">
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="border-2 border-red-200 rounded-xl overflow-hidden bg-white shadow-md"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full text-left p-5 flex items-center justify-between hover:bg-red-50 transition-colors"
                >
                  <span className="font-bold text-gray-800 text-lg pr-4">
                    {faq.question}
                  </span>
                  {openFaq === index ? (
                    <ChevronUp className="w-6 h-6 text-red-600 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-red-600 flex-shrink-0" />
                  )}
                </button>
                {openFaq === index && (
                  <div className="p-5 pt-0 border-t-2 border-red-100">
                    <p className="text-gray-700 text-base leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-6 mb-12">
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="block"
          >
            <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold text-xl py-5 px-8 rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300 border-4 border-white flex items-center justify-center gap-3">
              <MessageCircle className="w-7 h-7" />
              Falar no WhatsApp agora
            </button>
          </a>

          <a href="#home" className="block">
            <button className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold text-xl py-5 px-8 rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300 border-4 border-yellow-400 flex items-center justify-center gap-3">
              <Gift className="w-7 h-7" />
              Voltar para resgatar o presentinho
            </button>
          </a>
        </section>

        <section className="text-center bg-yellow-400 rounded-3xl p-8 shadow-2xl">
          <h3 className="text-2xl md:text-3xl font-bold text-red-900 mb-4">
            Ainda com dúvidas?
          </h3>
          <p className="text-red-900 text-lg mb-6">
            Chama no WhatsApp que a gente te ajuda em tudo! É rapidinho e fácil.
          </p>
          <a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block"
          >
            <button className="bg-green-700 hover:bg-green-800 text-white font-bold text-xl py-4 px-8 rounded-full shadow-xl transform hover:scale-105 transition-all duration-300 border-4 border-white">
              Chamar no WhatsApp
            </button>
          </a>
        </section>
      </div>
    </div>
  );
}
