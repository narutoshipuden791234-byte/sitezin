import { AlertCircle } from 'lucide-react';

export default function PromoBanner() {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-yellow-500 via-yellow-400 to-yellow-500 text-red-900 py-2 px-4 text-center font-bold text-sm md:text-base shadow-lg animate-pulse">
      <div className="flex items-center justify-center gap-2">
        <AlertCircle className="w-5 h-5 flex-shrink-0" />
        <span>Promoção limitada de Natal – Resgate antes que acabe!</span>
      </div>
    </div>
  );
}
