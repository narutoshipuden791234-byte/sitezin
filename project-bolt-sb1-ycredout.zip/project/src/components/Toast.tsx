import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface ToastMessage {
  id: string;
  message: string;
  type: 'success';
}

interface ToastProps {
  message: ToastMessage;
  onRemove: (id: string) => void;
}

function ToastItem({ message, onRemove }: ToastProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onRemove(message.id);
    }, 7000);

    return () => clearTimeout(timer);
  }, [message.id, onRemove]);

  return (
    <div className="animate-slide-in bg-white/95 text-gray-800 px-5 py-3 rounded-lg shadow-xl flex items-center justify-between gap-3 border-2 border-green-400 max-w-xs">
      <p className="font-medium text-xs md:text-sm leading-snug">{message.message}</p>
      <button
        onClick={() => onRemove(message.id)}
        className="hover:bg-gray-100 p-1 rounded transition-colors flex-shrink-0"
      >
        <X className="w-3 h-3 text-gray-600" />
      </button>
    </div>
  );
}

interface ToastContainerProps {
  messages: ToastMessage[];
  onRemove: (id: string) => void;
}

export function ToastContainer({ messages, onRemove }: ToastContainerProps) {
  return (
    <div className="fixed bottom-6 right-4 md:right-6 z-50 space-y-2 pointer-events-auto max-w-sm">
      {messages.map((message) => (
        <ToastItem
          key={message.id}
          message={message}
          onRemove={onRemove}
        />
      ))}
    </div>
  );
}

export function useToast() {
  const [messages, setMessages] = useState<ToastMessage[]>([]);

  const addToast = (message: string) => {
    const id = Math.random().toString(36).substring(2, 11);
    setMessages((prev) => [...prev, { id, message, type: 'success' }]);
  };

  const removeToast = (id: string) => {
    setMessages((prev) => prev.filter((msg) => msg.id !== id));
  };

  return { messages, addToast, removeToast };
}
