import { Gift } from 'lucide-react';

interface HeaderProps {
  currentPage: string;
}

export default function Header({ currentPage }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-red-800/95 backdrop-blur-sm shadow-lg border-b-4 border-yellow-400">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-center">
          <a href="#home" className="flex items-center gap-3 text-white hover:text-yellow-300 transition-colors">
            <Gift className="w-8 h-8 text-yellow-400" />
            <h1 className="text-2xl md:text-3xl font-bold">
              Surpresa de Natal 2025
            </h1>
          </a>
        </div>
      </div>
    </header>
  );
}
