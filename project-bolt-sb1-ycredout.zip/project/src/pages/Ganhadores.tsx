import { CheckCircle, Trophy, Gift } from 'lucide-react';

export default function Ganhadores() {
  const winners = [
    { name: 'Carlos', city: 'Belo Horizonte', value: 170 },
    { name: 'Fernanda', city: 'Porto Alegre', value: 170 },
    { name: 'Ricardo', city: 'Curitiba', value: 170 },
    { name: 'Juliana', city: 'Salvador', value: 170 },
    { name: 'Pedro', city: 'Brasília', value: 170 },
    { name: 'Camila', city: 'Fortaleza', value: 170 },
    { name: 'Lucas', city: 'Recife', value: 170 },
    { name: 'Patrícia', city: 'Manaus', value: 170 },
  ];

  return (
    <div className="pt-12 pb-8">
      <div className="container mx-auto px-4 max-w-6xl">
        <section className="text-center mb-12">
          <div className="inline-block bg-yellow-400 rounded-full p-4 mb-6">
            <Trophy className="w-16 h-16 text-red-900" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Olha só quem já ganhou a surpresa de Natal 🎁
          </h1>
          <p className="text-xl text-yellow-200 max-w-3xl mx-auto">
            Essas pessoas clicaram, baixaram o app e receberam direto no Pix. Você pode ser o próximo!
          </p>
        </section>

        <section className="mb-12">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {winners.map((winner, index) => (
              <div
                key={index}
                className="bg-white/95 rounded-2xl p-6 shadow-xl transform hover:scale-105 transition-all duration-300 border-4 border-green-400/50"
              >
                <div className="flex items-center justify-center mb-4">
                  <div className="bg-green-100 rounded-full p-3">
                    <CheckCircle className="w-10 h-10 text-green-600" />
                  </div>
                </div>

                <div className="text-center">
                  <h3 className="font-bold text-xl text-gray-800 mb-1">
                    {winner.name}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3">
                    {winner.city}
                  </p>

                  <div className="bg-green-50 border-2 border-green-300 rounded-lg p-3 mb-3">
                    <p className="text-xs text-gray-600 mb-1">Recebeu no Pix</p>
                    <p className="text-2xl font-bold text-green-700">
                      R$ {winner.value}
                    </p>
                  </div>

                  <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-2">
                    <p className="text-sm text-gray-700 font-medium">
                      "Surpresa incrível pro Natal!"
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="text-center bg-gradient-to-r from-green-600 to-green-700 rounded-3xl p-8 md:p-12 shadow-2xl border-4 border-yellow-400">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Milhares já estão aproveitando essa promoção natalina! 🎄
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Não fica de fora! Garanta sua surpresa de Natal agora mesmo.
          </p>
          <a href="#home" className="inline-block">
            <button className="bg-red-700 hover:bg-red-800 text-white font-bold text-xl md:text-2xl py-5 px-10 rounded-full shadow-2xl transform hover:scale-105 transition-all duration-300 border-4 border-white flex items-center justify-center gap-3">
              <Gift className="w-8 h-8" />
              Quero minha surpresa de Natal também 🎄
            </button>
          </a>
        </section>
      </div>
    </div>
  );
}
