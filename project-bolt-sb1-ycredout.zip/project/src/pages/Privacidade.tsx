import { Shield } from 'lucide-react';

export default function Privacidade() {
  return (
    <div className="pt-12 pb-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <section className="text-center mb-12">
          <div className="inline-block bg-blue-400 rounded-full p-4 mb-6">
            <Shield className="w-16 h-16 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 drop-shadow-lg">
            Política de Privacidade
          </h1>
          <p className="text-xl text-yellow-200">
            Sua privacidade é importante para nós
          </p>
        </section>

        <section className="bg-white/95 rounded-3xl p-8 md:p-12 shadow-2xl">
          <div className="prose prose-lg max-w-none text-gray-700">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              Informações Gerais
            </h2>
            <p className="mb-6 leading-relaxed">
              Este site tem como objetivo divulgar uma promoção oficial do TikTok Lite.
              Não coletamos dados pessoais dos visitantes além das informações
              necessárias para o funcionamento básico do site.
            </p>

            <h2 className="text-2xl font-bold text-gray-800 mb-4 mt-8">
              Links Externos
            </h2>
            <p className="mb-6 leading-relaxed">
              Este site contém links para plataformas externas (TikTok Lite e WhatsApp).
              Ao clicar nesses links, você será direcionado para serviços de terceiros
              que possuem suas próprias políticas de privacidade.
            </p>

            <h2 className="text-2xl font-bold text-gray-800 mb-4 mt-8">
              Cookies
            </h2>
            <p className="mb-6 leading-relaxed">
              Este site pode utilizar cookies básicos para melhorar a experiência
              de navegação do usuário. Você pode desabilitar cookies nas configurações
              do seu navegador.
            </p>

            <h2 className="text-2xl font-bold text-gray-800 mb-4 mt-8">
              Responsabilidade
            </h2>
            <p className="mb-6 leading-relaxed">
              A promoção divulgada neste site é de responsabilidade do TikTok Lite.
              Não nos responsabilizamos por problemas técnicos, alterações nos termos
              da promoção ou questões relacionadas ao pagamento dos bônus.
            </p>

            <h2 className="text-2xl font-bold text-gray-800 mb-4 mt-8">
              Contato
            </h2>
            <p className="mb-6 leading-relaxed">
              Para dúvidas sobre esta política ou sobre o site, entre em contato
              através do WhatsApp disponibilizado na página de Suporte.
            </p>

            <div className="bg-green-50 border-l-4 border-green-500 p-6 mt-8">
              <p className="text-gray-700 font-medium">
                Última atualização: Dezembro de 2024
              </p>
            </div>
          </div>
        </section>

        <section className="mt-8 text-center">
          <a href="#home">
            <button className="bg-red-700 hover:bg-red-800 text-white font-bold text-lg py-4 px-8 rounded-full shadow-xl transform hover:scale-105 transition-all duration-300">
              Voltar para o início
            </button>
          </a>
        </section>
      </div>
    </div>
  );
}
