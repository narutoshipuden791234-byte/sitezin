import { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import PromoBanner from './components/PromoBanner';
import SnowEffect from './components/SnowEffect';
import { ToastContainer, useToast } from './components/Toast';
import Home from './pages/Home';
import Suporte from './pages/Suporte';
import Ganhadores from './pages/Ganhadores';
import Privacidade from './pages/Privacidade';

type Page = 'home' | 'suporte' | 'ganhadores' | 'privacidade';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const { messages, addToast, removeToast } = useToast();

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1) || 'home';
      setCurrentPage(hash as Page);
      window.scrollTo(0, 0);
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    const names = ['Ana', 'João', 'Maria', 'Pedro', 'Juliana', 'Carlos', 'Fernanda', 'Lucas', 'Beatriz', 'Roberto'];
    const values = [100, 110, 120, 130, 140, 150, 170];
    const messageTemplates = [
      '{name} acabou de ganhar R$ {value} no Pix! 🎄',
      '{name} resgatou R$ {value} há poucos segundos 🎁',
      '{name} recebeu R$ {value} agora mesmo ✨',
      '{name} ganhou R$ {value} direto no Pix! 🎅',
      '{name} acabou de receber R$ {value} pro Natal ❤️',
      '{name} resgatou R$ {value} há instantes 🎄',
      '{name} ganhou R$ {value}! Surpresa de Natal 🎁',
      '{name} recebeu R$ {value} no Pix agora ✨',
    ];

    const interval = setInterval(() => {
      const randomName = names[Math.floor(Math.random() * names.length)];
      const randomValue = values[Math.floor(Math.random() * values.length)];
      const randomTemplate = messageTemplates[Math.floor(Math.random() * messageTemplates.length)];
      const finalMessage = randomTemplate
        .replace('{name}', randomName)
        .replace('{value}', randomValue.toString());

      addToast(finalMessage);
    }, 15000 + Math.random() * 15000);

    return () => clearInterval(interval);
  }, [addToast]);

  const renderPage = () => {
    switch (currentPage) {
      case 'suporte':
        return <Suporte />;
      case 'ganhadores':
        return <Ganhadores />;
      case 'privacidade':
        return <Privacidade />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-900 via-green-900 to-red-950 relative overflow-hidden">
      <SnowEffect />
      <PromoBanner />
      <Header currentPage={currentPage} />
      <main className="relative z-10">
        {renderPage()}
      </main>
      <Footer />
      <ToastContainer messages={messages} onRemove={removeToast} />
    </div>
  );
}

export default App;
